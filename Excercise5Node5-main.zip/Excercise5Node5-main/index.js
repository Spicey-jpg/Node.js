//promise allows you to use a sink ans a weight 
import mysql from 'mysql2/promise';
import {config} from 'dotenv';
import express from 'express';
config();

// promise to get connection from pool
const pool = mysql.createPool({
    host:process.env.HOST,
    user:process.env.USER,
    password:process.env.PASSWORD,
    database:process.env.DATABASE

});

const app = express();

app.listen(3000, () => console.log('Server started on port 3000'));
//----------------------------------------------------------------Routes----------------------------------------------------------------
//gets all products from the database
app.get('/products', async (req, res) => {
    res.json({
        products: await productsTable()
    });
});
//this is the function to a single product
app.get('/products/:product_code', async (req, res) => {
    res.json({
        users: await singleProduct (req.params.product_code)
    });
});
//this is the function to add a product
app.post('/products', async (req, res) => {
    res.json({
        users: await addProduct ('gun1', 'M4', 100.00, 3)
    });
})
//this is the function to delete a product based on the product code
app.delete('/products/:product_code', async (req, res) => {
    res.json({
        users: await deleteProduct (req.params.product_code)
    });
})
//this is the function to update a product based on the product code
app.put('/products/:product_code', async (req, res) => {
    res.json({
        users: await updateProduct (req.params.product_code)
    });
})
//----------------------------------------------------------------Functions----------------------------------------------------------------
//this function gets all products from the database
const productsTable = async () => {
    let [data] = await pool.query('SELECT * FROM shopleft.products;');
    return data;
}
//this function gets a single product from the database
const singleProduct = async (product_code) => {
    let [data] = await pool.query('SELECT * FROM shopleft.products WHERE product_code = ?;', [product_code]);
    return data;
}
//this function adds a product to the database
const addProduct = async (product_code, product_name, product_price, product_quantity) => {
     await pool.query('INSERT INTO `shopleft`.`products` (`product_code`, `product_name`, `product_price`, `product_quantity`) VALUES (?, ?, ?, ?);', [product_code, product_name, product_price, product_quantity]);
    return await productsTable();
}

//this function deletes a product from the database based on its product code
const deleteProduct = async (product_code) => {
    await pool.query('DELETE FROM `shopleft`.`products` WHERE product_code = ?;', [product_code]);
    return await productsTable();
}

//this function updates a product in the database based on its product code
const updateProduct = async (product_code) => {
    await pool.query('UPDATE `shopleft`.`products` SET `product_name` = "M16" WHERE `product_code` = ?;', [product_code]);
    return await productsTable();
}