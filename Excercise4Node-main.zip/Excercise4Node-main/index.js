import mysql from 'mysql2/promise'
import {config} from 'dotenv'
config()

const pool = mysql.createPool({
    hostname:process.env.HOSTNAME,
    user:process.env.USER,
    password:process.env.PASSWORD,
    database:process.env.DATABASE
})

const getUsers = async () => {
    let [data] = await pool.query('SELECT * FROM pick_n_steal')
    return data
}

// console.log('getUsers:', await getUsers());

// const getEmp = async () => {
//     let [data] = await pool.query('SELECT * FROM pick_n_steal WHERE (employee_id = 1);');
//     return data
// }

// console.log('getEmp:', await getEmp());

const addEmp = async() => {
    let [data] = await pool.query('INSERT INTO pick_n_steal (employee_id, first_name, last_name, email, phone_number, department, salary)VALUES (?, ?, ?, ?, ?, ?, ?)', [5, 'Joseph', 'Stalin', 'joseph.stalin@gmail.com', '555-05040', 'CEO', '10000.00'])
    return data;       
}

// const delEmp = async (employee_id) => {
//     let [data] = await pool.query('DELETE FROM pick_n_steal WHERE employee_id = ?', [employee_id])
//     return data
// }
// console.log(await delEmp(1));


// console.log('getUsers:', await getUsers());

const updateEmp = async (employee_id) => {
    let [data] = await pool.query(
        `UPDATE pick_n_steal 
         SET first_name = 'Peter', 
             last_name = 'Parker', 
             email = 'peter.parker@gmail.com', 
             phone_number = '555-0845', 
             department = 'Crime, 
             salary = '100000000.00' 
         WHERE employee_id = ?`, 
        [employee_id]
    );
    return data;
};


console.log(await updateEmp(2));
